function Project3() {
    return (
      <div className="project-details">
        <h1>Лендинг для бизнеса</h1>
        <img src="/images/project3.jpg" alt="Лендинг для бизнеса" />
        <p>Лендинг создан с использованием Tilda и кастомного кода.</p>
      </div>
    );
  }
  
  export default Project3;
  