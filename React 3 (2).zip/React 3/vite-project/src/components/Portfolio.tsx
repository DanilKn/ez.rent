import { useNavigate } from "react-router-dom";
import "../css/Portfolio.css";

function Portfolio() {
  const navigate = useNavigate();

  const houses = [
    { id: 1, img: "/src/images/project1-1.jpg", title: "Дом в лесу", price: "25 000 000 ₸", address: "Алматы, мкр. Нурлытау", route: "/project1" },
    // { id: 2, img: "/src/images/project2.jpg", title: "Современный коттедж", price: "35 000 000 ₸", address: "Алматы, мкр. Дубок-2", route: "/project2" },
    // { id: 3, img: "/src/images/project3.jpg", title: "Дом у озера", price: "40 000 000 ₸", address: "Алматы, Бостандыкский р-н", route: "/project3" },
    // { id: 4, img: "/src/images/project4.jpg", title: "Семейный дом", price: "30 000 000 ₸", address: "Алматы, мкр. Таугуль", route: "/project4" },
    // { id: 5, img: "/src/images/project5.jpg", title: "Элитный особняк", price: "55 000 000 ₸", address: "Алматы, мкр. Кок-Тобе", route: "/project5" },
  ];

  return (
    <div className="portfolio">

      <div className="portfolio-container">
        {houses.map((house) => (
          <div key={house.id} className="portfolio-card" onClick={() => navigate(house.route)}>
            <img src={house.img} alt={house.title} className="portfolio-image" />
            <div className="portfolio-details">
              <h2>{house.title}</h2>
              <p className="portfolio-price">{house.price}</p>
              <p className="portfolio-address">{house.address}</p>
              <button className="portfolio-button" onClick={(e) => { e.stopPropagation(); navigate(house.route); }}>
                Подробнее
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Portfolio;
