// Contacts.jsx
import "../css/Contacts.css";

function Contacts() {
  return (
    <div className="contacts">

      <div className="contacts-section">
        <h2>Наши менеджеры</h2>
        <div className="manager-card">
          <p className="manager-name">Азиз</p>
          <p className="manager-phone">+7 777 696 93 86</p>
        </div>
        <div className="manager-card">
          <p className="manager-name">Данил</p>
          <p className="manager-phone">+7 705 118 02 02</p>
        </div>
      </div>

      <div className="contacts-section">
        <h2>Социальные сети</h2>
        <p>Instagram: ez.rent</p>
        <p>TikTok: ez.rent</p>
      </div>

      <div className="contacts-section">
        <h2>График работы</h2>
        <p>Ежедневно с 8:00 до 00:00</p>
      </div>
    </div>
  );
}

export default Contacts;
