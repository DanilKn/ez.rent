import { Link } from "react-router"

const Login = () => {
    return(
        <div>
            Login
            <Link to="/">На главную</Link>
        </div>
    )
}

export default Login