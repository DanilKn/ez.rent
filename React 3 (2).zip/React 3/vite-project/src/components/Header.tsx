import { Link } from 'react-router-dom';
import '../css/Header.css'; 

const Header = () => {
  return (
    <header className="header">
      <nav>
        <ul className="nav-list">
          <li><Link to="/" className="nav-item">Главная</Link></li>
          <li><Link to="/portfolio" className="nav-item">Каталог</Link></li>
          <li><Link to="/contacts" className="nav-item">Контакты</Link></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
