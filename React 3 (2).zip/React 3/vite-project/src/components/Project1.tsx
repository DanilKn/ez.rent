import "../css/Project1.css";
import { useNavigate } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function Project1() {
  const navigate = useNavigate();

  const images = [
    "/src/images/project1-2.jpg",
    "/src/images/project1-1.jpg",
    "/src/images/project1-3.jpg",
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
  };

  return (
    <div className="project1">
      <Slider {...settings} className="project1-slider">
        {images.map((src, index) => (
          <div key={index}>
            <img src={src} alt={`Дом ${index + 1}`} />
          </div>
        ))}
      </Slider>

      <div className="project1-info">
        <div className="project1-prices">
          <p><strong>Будние дни:</strong> 80 000 ₸/сутки</p>
          <p><strong>Выходные дни:</strong> 120 000 ₸/сутки</p>
        </div>

        <div className="project1-description">
          <h2>Описание:</h2>
          <p>
            Просторный коттедж с 4 спальнями, гостиной, кухней и баней. Вместимость до 10 человек.
            Бассейн, зона барбекю, караоке, Wi-Fi, парковка на 5 машин.
          </p>
        </div>

        <button 
          className="project1-address-button"
          onClick={() => window.open("https://2gis.kz/almaty", "_blank")}
        >
          Смотреть на 2ГИС
        </button>

        <button 
          className="project1-booking-button"
          onClick={() => navigate("/booking")}
        >
          Забронировать
        </button>
      </div>
    </div>
  );
}

export default Project1;
