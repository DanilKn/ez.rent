function Project2() {
    return (
      <div className="project-details">
        <h1>Интернет-магазин</h1>
        <img src="/images/project2.jpg" alt="Интернет-магазин" />
        <p>Этот интернет-магазин разработан на React и интегрирован с Shopify.</p>
      </div>
    );
  }
  
  export default Project2;
  