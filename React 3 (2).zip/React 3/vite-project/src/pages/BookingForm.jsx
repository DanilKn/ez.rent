import React, { useState } from "react";
import emailjs from "@emailjs/browser";
import "../css/BookingForm.css";

function BookingForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    date: "",
    days: 1,
    guests: 1,
    comment: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const serviceID = "service_menger";
    const templateID = "template_order";
    const publicKey = "oGBH2Jxc4iq0f2X8-";

    const templateParams = {
      name: formData.name,
      phone: formData.phone,
      date: formData.date,
      days: formData.days,
      guests: formData.guests,
      comment: formData.comment,
    };

    emailjs.send(serviceID, templateID, templateParams, publicKey)
      .then(() => {
        alert("Бронирование успешно отправлено!");
        setFormData({
          name: "",
          phone: "",
          date: "",
          days: 1,
          guests: 1,
          comment: "",
        });
      })
      .catch((error) => {
        console.error("Ошибка при отправке:", error);
        alert("Произошла ошибка при отправке. Попробуйте позже.");
      });
  };

  return (
    <div className="booking-form-container">
      <h2>Форма бронирования</h2>
      <form onSubmit={handleSubmit} className="booking-form">
        <label>
          Ваше имя:
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </label>

        <label>
          Телефон:
          <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required placeholder="+7 (___) ___-__-__" />
        </label>

        <label>
          Дата заезда:
          <input type="date" name="date" value={formData.date} onChange={handleChange} required />
        </label>

        <label>
          Количество суток:
          <input type="number" name="days" value={formData.days} onChange={handleChange} min="1" required />
        </label>

        <label>
          Количество гостей:
          <input type="number" name="guests" value={formData.guests} onChange={handleChange} min="1"  required />
        </label>

        <label>
          Комментарий (необязательно):
          <textarea name="comment" value={formData.comment} onChange={handleChange} />
        </label>

        <button type="submit">Отправить заявку</button>
      </form>
    </div>
  );
}

export default BookingForm;
