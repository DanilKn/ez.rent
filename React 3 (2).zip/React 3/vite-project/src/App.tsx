import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";
import Home from "./components/Home";
import Portfolio from "./components/Portfolio";
import Contacts from "./components/Contacts";
import Header from "./components/Header";
import Project1 from "./components/Project1";
import Project2 from "./components/Project2";
import Project3 from "./components/Project3";
import BookingForm from "./pages/BookingForm";
import whatsappIcon from "/src/images/whatssap.png"; // путь к вашей иконке

const App = () => {
  const location = useLocation();
  const hideWhatsapp = location.pathname === "/project1" || location.pathname === "/booking";

  return (
    <>
      <Header /> 
      <div className="content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/contacts" element={<Contacts />} />
          <Route path="/project1" element={<Project1 />} />
          <Route path="/project2" element={<Project2 />} />
          <Route path="/project3" element={<Project3 />} />
          <Route path="/booking" element={<BookingForm />} />
        </Routes>
      </div>

      {/* Иконка WhatsApp — показываем, если не нужно скрывать */}
      {!hideWhatsapp && (
        <a 
          href="https://wa.me/77001234567" 
          target="_blank" 
          rel="noopener noreferrer"
          style={{
            position: 'fixed',
            bottom: '20px',
            right: '0px',
            zIndex: 1000,
          }}
        >
          <img 
            src={whatsappIcon} 
            alt="Связаться в WhatsApp"
            style={{
              height: '60px',
              cursor: 'pointer',
            }}
          />
        </a>
      )}
    </>
  );
};

export default App;
